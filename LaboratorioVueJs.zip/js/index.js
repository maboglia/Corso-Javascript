function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Studente = function Studente(nome, cognome, web, img) {
  _classCallCheck(this, Studente);

  this.nome = nome;
  this.cognome = cognome;
  this.web = web;
  this.img = img;
};

var app = new Vue({
  el: '#app',
  data: {
    message: '',
    elencoStudenti: [new Studente("Cristiano", "Maffeis", "http://www.twingo.fr", "https://lightstorage.ecodibergamo.it/mediaon/cms.quotidiani/storage/site_media/media/photologue/2014/11/10/photos/cache/roncalli-montini-papi-del-vaticano-iigli-atti-del-convegno-ce-il-card_f0317a66-68d6-11e4-ae05-8d5c2159be46_700_455_big_story_linked_ima.jpg"), new Studente("Marco", "Di Palma", "http://www.top.com")],
    isAcceso: true,
    colore: 'green',
    styleObj: {
      backgroundColor: "green",
      width: '300px'
    }
  },
  methods: {
    accendiSpegni: function accendiSpegni() {
      this.isAcceso = !this.isAcceso;
    }
  },
  computed: {
    filtraRisultati: function filtraRisultati() {
      var _this = this;

      return this.elencoStudenti.filter(function (studente) {
        return studente.nome.includes(_this.message);
      });
    }
  }
});