//var, let, const
const btn = document.getElementById('bottone');
const output = document.getElementById('output');
const input = document.getElementById('testo');
const url = "https://jsonplaceholder.typicode.com/users/";



btn.onclick = function() {
    console.log('funziona!');
    let inputUser = input.value;
    //output.style.backgroundColor = inputUser;

    let xhr = new XMLHttpRequest();

    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {

            console.log(xhr.responseText);
            let obj = JSON.parse(xhr.responseText);
            output.innerHTML = '<p>' + obj.name + '</p>';
            output.innerHTML += '<p>' + obj.email + '</p>';



        }
    };

    xhr.open("GET", url + inputUser);
    xhr.send();


}